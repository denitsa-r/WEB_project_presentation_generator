<!DOCTYPE html>
<html lang="bg">
<head>
    <meta charset="UTF-8">
    <title><?= $data['title'] ?></title>
</head>
<body>
    <h1><?= $data['title'] ?></h1>
    <p>Това е начална страница на MVC системата.</p>
</body>
</html>
