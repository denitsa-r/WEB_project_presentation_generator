<?php
header('Location: /WEB_project_presentation_generator/public/auth/login');
exit; 